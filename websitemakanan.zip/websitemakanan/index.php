<?php
session_start();

if (!isset($_SESSION["orders"])) {
    $_SESSION["orders"] = [];
}

if (isset($_POST["add"])) {
    $_SESSION["orders"][] = [
        "food"  => $_POST["food"],
        "qty"   => $_POST["qty"],
        "price" => $_POST["price"]
    ];
}

if (isset($_POST["checkout"])) {
    $_SESSION["name"]   = $_POST["name"];
    $_SESSION["address"] = $_POST["address"];
    $_SESSION["payment"] = $_POST["payment"];
    $_SESSION["status"]  = "Pesanan diterima";
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Food Order</title>

<style>
body{
    margin:0;
    font-family:Poppins,Arial;
    background:#fff7f0;
}

/* HEADER */
header{
    padding:15px 40px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    background:white;
    box-shadow:0 2px 10px rgba(0,0,0,.08);
}
nav a{
    margin:0 12px;
    text-decoration:none;
    font-weight:600;
    color:#333;
}
nav a:hover{color:#ff7b00}

/* HERO */
.hero{
    display:flex;
    padding:50px;
    background:linear-gradient(135deg,#ffb25c,#ff7b00);
    border-bottom-left-radius:60px;
    border-bottom-right-radius:60px;
    color:white;
}
.hero-left{flex:1}
.hero-left h1{font-size:38px}
.search-box{
    background:white;
    padding:10px 15px;
    border-radius:30px;
    width:70%;
    color:black;
}
.hero-right img{
    width:380px;
    border-radius:30px;
    box-shadow:0 10px 20px rgba(0,0,0,.2);
}

.section{padding:30px 40px}

.feature-card{
    display:inline-block;
    background:white;
    padding:15px;
    width:200px;
    text-align:center;
    border-radius:20px;
    margin:10px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
}

.card{
    border:1px solid #eee;
    border-radius:15px;
    padding:15px;
    margin:10px;
    display:inline-block;
    width:210px;
}

button{
    border:none;
    padding:8px 15px;
    border-radius:20px;
    background:orange;
    cursor:pointer;
    font-weight:bold;
}

input,textarea,select{
    padding:6px;
    width:95%;
}

/* ===== STATUS ===== */
.status-flex{
    display:flex;
    gap:30px;
    align-items:center;
}

/* ===== ANIMASI KURIR GIF ===== */
.kurir-area{
    width:100%;
    height:160px;
    position:relative;
    overflow:hidden;
    background:#fff;
    border-radius:20px;
    box-shadow:0 5px 15px rgba(0,0,0,.1);
    margin-top:20px;
}

.kurir-gif{
    position:absolute;
    bottom:10px;
    width:140px;
    animation: jalanKurir 6s linear infinite;
}

@keyframes jalanKurir{
    0%{left:100%;}
    100%{left:-150px;}
}

/* ===== STRUK ===== */
.struk{
    width:300px;
    background:#fff;
    padding:15px;
    font-family:monospace;
    box-shadow:0 0 10px rgba(0,0,0,.2);
    margin:auto;
}
.struk h3{text-align:center;margin:0}
.struk hr{
    border:none;
    border-top:1px dashed #000;
    margin:10px 0;
}
.struk .item{
    display:flex;
    justify-content:space-between;
}
.struk .total{
    font-weight:bold;
    font-size:16px;
}
.struk .footer{
    text-align:center;
    font-size:12px;
    margin-top:10px;
}
.judul-struk{
    text-align:center;
    font-weight:bold;
    margin-bottom:10px;
}
</style>
</head>
<body>

<header>
    <h2 style="color:#ff7b00;">GoFood</h2>
    <nav>
        <a href="?page=home">Home</a>
        <a href="?page=menu">Menu</a>
        <a href="?page=checkout">Checkout</a>
        <a href="?page=status">Status Kirim</a>
        <a href="?page=struk">Cetak Struk</a>
    </nav>
</header>

<?php
$page = isset($_GET["page"]) ? $_GET["page"] : "home";

/* HOME */
if ($page=="home"){ ?>
<div class="hero">
    <div class="hero-left">
        <h1>Taste The Difference,<br>Taste The Good Life</h1>
        <p>Makanan enak, hidup lebih bahagia</p>
        <div class="search-box">
            🔍 <input type="text" placeholder="Search food here..." style="border:none;outline:none;width:85%;">
        </div>
    </div>
    <div class="hero-right">
        <img src="kurir.jpeg">
    </div>
</div>

<div class="section">
    <h2>Eat Like A Family</h2>
    <div class="feature-card">🍳 We Make</div>
    <div class="feature-card">🚚 We Deliver</div>
    <div class="feature-card">🍽️ You Eat</div>
</div>
<?php } ?>

<?php
/* MENU */
if ($page=="menu"){ ?>
<div class="section">
<h2>Menu Makanan Populer</h2>

<?php
$foods = [
["Burger","burger.jpeg",25000],
["Pizza","pizza.jpeg",45000],
["Fried Chicken","ayam.jpeg",20000],
["Spaghetti","spageti.jpeg",30000],
["Milkshake","milk.jpeg",15000],
["Nasi Goreng","nasgor.jpeg",18000],
["Mie Ayam","Mie Ayam.jpeg",16000],
["Bakso","bkso.jpeg",17000]
];

foreach($foods as $f){ ?>
<div class="card">
<img src="<?= $f[1] ?>" width="190"><br>
<b><?= $f[0] ?></b><br>
Harga: Rp <?= $f[2] ?><br><br>
<form method="post">
<input type="hidden" name="food" value="<?= $f[0] ?>">
<input type="hidden" name="price" value="<?= $f[2] ?>">
Jumlah:
<input type="number" name="qty" value="1" min="1"><br><br>
<button name="add">Pesan</button>
</form>
</div>
<?php } ?>
</div>
<?php } ?>

<?php
/* CHECKOUT */
if ($page=="checkout"){ ?>
<div class="section">
<h2>Checkout Pesanan</h2>
<form method="post">
Nama Penerima<br>
<input name="name" required><br><br>
Alamat Pengiriman<br>
<textarea name="address" required></textarea><br><br>
Metode Pembayaran<br>
<select name="payment">
<option>COD</option>
<option>Dana</option>
<option>GoPay</option>
</select><br><br>
<button name="checkout">Buat Pesanan</button>
</form>
</div>
<?php } ?>

<?php
/* STATUS */
if ($page=="status"){ ?>
<div class="section">
<h2>Status Pengiriman</h2>

<?php
if (!isset($_SESSION["status"])) {
    echo "Belum ada pesanan.";
} else {
    echo "<b>Status:</b> ".$_SESSION["status"];
?>
<ul>
<li>Pesanan diterima</li>
<li>Sedang dimasak</li>
<li>Dikemas</li>
<li>Dikirim kurir</li>
<li>Sampai tujuan</li>
</ul>

<!-- KURIR JALAN OTOMATIS -->
<div class="kurir-area">
    <img src="Scooter Courier.gif" class="kurir-gif">
</div>

<?php } ?>
</div>
<?php } ?>

<?php
/* STRUK */
if ($page=="struk"){ ?>
<div class="section">

<div class="judul-struk">STRUK PESANAN</div>

<?php if (!isset($_SESSION["name"])) {
echo "Belum ada pesanan.";
} else { ?>

<div class="struk">
<h3>GOFOOD</h3>
<p style="text-align:center;font-size:12px;">Jl. Online Food No.1</p>
<hr>

Nama: <?= $_SESSION["name"] ?><br>
Alamat: <?= $_SESSION["address"] ?><br>
Bayar: <?= $_SESSION["payment"] ?><br>

<hr>
<?php
$total=0;
foreach($_SESSION["orders"] as $o){
$sub=$o["qty"]*$o["price"];
$total+=$sub;
?>
<div class="item">
<span><?= $o["qty"] ?>x <?= $o["food"] ?></span>
<span>Rp <?= $sub ?></span>
</div>
<?php } ?>
<hr>
<div class="item total">
<span>TOTAL</span>
<span>Rp <?= $total ?></span>
</div>
<hr>
<div class="footer">
Terima Kasih 🙏<br>
Pesanan Anda Segera Dikirim
</div>
</div>

<?php } ?>
</div>
<?php } ?>

</body>
</html>
